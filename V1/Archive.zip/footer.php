	</div><!-- end #main -->
	
	<div id="footer">
		<div id="copyrightcontact">
			<p>Copyright &copy;2010 Westlake Plastic Surgery.<br /> 
			All Rights Reserved.</p>
			<p>4407 Bee Cave Road, Suite 303 | Austin, Texas 78746 <br/>
<a href="<?php bloginfo('url'); ?>/privacy-policy">PRIVACY POLICY   <br />                                                         
			Web Design &amp; Development: <a href="http://www.logicbydesign.com">Logic by Design</a></p>
		</div>
		<ul>
			<li><a href="<?php bloginfo('url'); ?>">Home</a></li>
			<li><a href="<?php bloginfo('url'); ?>/dr-caridi">Dr. Caridi</a></li>
			<li><a href="<?php bloginfo('url'); ?>/our-practice">Our Practice</a></li>
			<li><a href="<?php bloginfo('url'); ?>/procedures">Procedures</a></li>
			<li><a href="<?php bloginfo('url'); ?>/photos">Photos</a></li>
			<li><a href="<?php bloginfo('url'); ?>/videos">Videos</a></li>
			<li><a href="<?php bloginfo('url'); ?>/fees-financing">Fees &amp; Financing</a></li>
			<li><a href="<?php bloginfo('url'); ?>/contact">Contact</a></li>
			<li><a href="<?php bloginfo('url'); ?>/testimonials">Testimonials</a></li>
		</ul>
		
		<div id="feedback">
			<h5><em>We would like to hear from you:</em></h5>
			<a href="<?php bloginfo('url'); ?>/feedback/">Feedback</a>
		</div>
		
		<div id="socialicons">
			<a href="http://www.facebook.com/pages/Westlake-Plastic-Surgery/186005065655?ref=ts" target="_blank" title="Our Facebook Page"><img src="<?php bloginfo('template_directory'); ?>/images/facebook-32x32.png" /></a>
			<a href="http://www.twitter.com/WestlakePS" target="_blank" title="Our Twitter Page"><img src="<?php bloginfo('template_directory'); ?>/images/twitter-32x32.png" /></a>
			<a href="http://www.youtube.com/user/wlplasticsurgery" target="_blank" title="Our YouTube Page"><img src="<?php bloginfo('template_directory'); ?>/images/youtube-32x32.png" /></a>
		</div>
	</div>

<!-- Bold Software Visitor Monitor HTML v3.50 (Website=West Lake Plastic Surgery,ChatWindow=West Lake Plastic Surgery,ChatInvitation=West Lake Plastic Surgery) -->
<script type="text/javascript">
  var _bcvma = _bcvma || [];
  _bcvma.push(["setAccountID", "735456910282213776"]);
  _bcvma.push(["setParameter", "WebsiteDefID", "3527929942681138317"]);
  _bcvma.push(["setParameter", "ChatWindowDefID", "1897261699583189401"]);
  _bcvma.push(["setParameter", "ChatWidth", "640"]);
  _bcvma.push(["setParameter", "ChatHeight", "480"]);
  _bcvma.push(["setParameter", "InvitationDefID", "1306558330671144654"]);
  _bcvma.push(["setParameter", "WindowScheme", "https"]);
  _bcvma.push(["setParameter", "VisitName", ""]);
  _bcvma.push(["setParameter", "VisitPhone", ""]);
  _bcvma.push(["setParameter", "VisitEmail", ""]);
  _bcvma.push(["setParameter", "VisitRef", ""]);
  _bcvma.push(["setParameter", "VisitInfo", ""]);
  _bcvma.push(["setParameter", "CustomUrl", "https://sitestaffimages.com/KB/westlakeplasticsurgery.html"]);
  _bcvma.push(["pageViewed"]);
  (function(){
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'http://') + "vmss.boldchat.com/aid/735456910282213776/bc.vms3/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  })();
</script>
<noscript>
<a href="http://www.boldchat.com" title="Live Chat Software" target="_blank"><img alt="Live Chat Software" src="https://vms.boldchat.com/aid/735456910282213776/bc.vmi?wdid=3527929942681138317&amp;vr=&amp;vi=&amp;vn=&amp;vp=&amp;ve=&amp;curl=" border="0" width="1" height="1" /></a>
</noscript>
<!-- /Bold Software Visitor Monitor HTML v3.50 -->

	<script type="text/javascript">
	sfHover = function() {
		var sfEls = document.getElementById("navbar").getElementsByTagName("li");
		for (var i=0; i<sfEls.length; i++) {
			sfEls[i].onmouseover=function() {
				this.className+=" sfhover";
			}
			sfEls[i].onmouseout=function() {
				this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
			}
		}
	}
	if (window.attachEvent) window.attachEvent("onload", sfHover);
	</script>
	<!--[if IE 6]>
		<script src="<?php bloginfo(template_url); ?>/script/DD_belatedPNG_0.0.8a-min.js"></script>
		<script>
		  /* EXAMPLE */
		  DD_belatedPNG.fix('#header #mainhead a, #header #navbar, #header #carousel #contactbutton, #header #pageheadercontent, #sidebar #asktheexpertform h4, #sidebar #asktheexpertform button, #sidebar #latestfromblog h3.widget-title, #sidebar #latestfromblog #visitblogbutton, #sidebar #joinnewsletter h4, #sidebar #joinnewsletter a, #footer #feedback a, #drcaridi, .itemImg, #headershadow');
	  
		  /* string argument can be any CSS selector */
		  /* .png_bg example is unnecessary */
		  /* change it to what suits you! */
		</script>
	<![endif]-->
<!-- Call Button Html -->
<div style="text-align: center; white-space: nowrap;position: fixed; bottom: 70px; right: 6px;">
<div>
<script type="text/javascript">
  document.write(unescape('%3Ca href="' + (('https:'==document.location.protocol)?'https':'http') +
    '://clicktocall.boldcall.com/aid/298867122326352203/bc.call" target="_blank"' +
    ' onclick="window.open(\'' + (('https:'==document.location.protocol)?'https':'http') + 
    '://clicktocall.boldcall.com/aid/298867122326352203/bc.call?' +
    'url=\' + escape(document.location.href), \'Call298867122326352203\', ' +
	'\'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=480,height=360\');' + 
    'return false;"%3E%3Cimg alt="" src="' + (('https:'==document.location.protocol)?'https':'http') + 
    '://pbi.boldcall.com/aid/298867122326352203/bc.pbi" border="0" /%3E%3C/a%3E'));
</script>
<noscript>
  <a href="https://clicktocall.boldcall.com/aid/298867122326352203/bc.call" target="_blank">
    <img alt="" src="https://pbi.boldcall.com/aid/298867122326352203/bc.pbi" border="0" />
  </a>
</noscript>
</div>
<div><font size="1" face="Arial"><a href="http://www.boldcall.com" style="text-decoration: none">
<font color="black"></font><b><font color="#7F7F00"></font></b></a></font></div>
</div>
<!-- Proactive Invite Script -->
<script type="text/javascript">
  document.write(unescape('%3Cscript type="text/javascript" src="' + 
    (('https:'==document.location.protocol)?'https':'http') + 
    '://pi.boldcall.com/aid/298867122326352203/bc.pi/pi.js"%3E%3C\/script%3E'));
</script>
<!-- / Proactive Invite Script -->
<!-- / Call Button Html -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"> 
</script> 
<script type="text/javascript"> 
_uacct = "UA-2050112-1";
urchinTracker();
</script> 
	<?php wp_footer(); ?>
</body>
</html>